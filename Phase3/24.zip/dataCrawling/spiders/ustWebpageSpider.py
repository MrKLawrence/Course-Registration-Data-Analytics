#!/usr/bin/python
#
#  The program is used for illustrating how to perform data crawling on one single webpage,
#  to save this webpage to the working directory of our computer
#

#Note that the structure of the fields from the target webpage is based on the model answer of the NoSQL record insertions, not anyone else

import pymongo
from pymongo import MongoClient
import datetime
import re
import scrapy
import sys

from scrapy.selector import Selector

logName = 'UstCourseWebpageSpider.txt'
logTxt = open(logName,'w', encoding='utf8')

class ustWebpageSpider(scrapy.Spider):
	name = "ustWebpageSpider"

	# start_urls = [ "http://comp4332.com/realistic/2017/Spring/01/25/09/00/subjects/ENEG.html" ]
	start_urls = [ "http://comp4332.com/trial/" ] #Please remove the two break in for loop.
	# start_urls = [ "http://comp4332.com/realistic/2017/Spring/01/25/09/00/subjects/ENEG.html" ]

	try:
		print("Making a MongoDB connection...")
		client = MongoClient("mongodb://localhost:27017")
		print("Getting a database named \"course\"")
		db = client["course"]
	except pymongo.errors.ConnectionFailure as error: 
		print("MongoDB Connection Failed! Error Message: \"{}\"".format(error))	

	def __init__(self, *args, **kwargs):
		super().__init__(*args, **kwargs)
		print("This is called at the beginning.")

	def closed(self, reason):
		print("This is called at the end.")
		try:
			logTxt.close()
			print("Closing MongoDB connection ...")
			self.client.close()
		except pymongo.errors.ConnectionFailure as error: 
			print("MongoDB Connection Failed! Error Message: \"{}\"".format(error))	
			
	def parse(self, response):
		print(response.url)
		crawlFilename = response.url.split("/")[-1]
		if crawlFilename=='':
			crawlFilename = response.url.split("/")[-2]
		with open(crawlFilename, "wb") as f:
			f.write(response.body)
		self.log("Saved File {} ".format(crawlFilename))
		listOfLinks = response.xpath("//a[@href]/@href").extract()
		for link in listOfLinks:
			yield response.follow(link, callback=self.parse_eachTimeslot)

		linkFilename = "listOfLinks.txt"
		with open(linkFilename, "w") as f:
			f.write(str(listOfLinks))
			for link in listOfLinks:
				f.write(link)
				f.write("\n")
		self.log("Saved File {} ".format(linkFilename))

	def parse_eachTimeslot(self, response):
		listOfSubjects = response.xpath("//a[@href]/@href").extract()
		for link in listOfSubjects:
			yield response.follow(link, callback=self.parse_subjects)

	def parse_subjects(self, response):
		coursesInfo =[]

		semester = response.xpath("//title/text()").extract()[0][0:14]

		courseTitles = response.xpath("//h2").extract()
		courseIndex = 0
		for oneCourseTitle in courseTitles:
			coursesInfo.append(dict())
			coursesInfo[courseIndex]['code'] = oneCourseTitle[4 : oneCourseTitle.find(' - ')]
			coursesInfo[courseIndex]['title'] = oneCourseTitle[oneCourseTitle.find(' - ') + 3 : oneCourseTitle.find(' units)') - 3]
			coursesInfo[courseIndex]['credits'] = oneCourseTitle[oneCourseTitle.find(' units)')-1]
			coursesInfo[courseIndex]['sections'] = list()
			courseIndex += 1
		courseIndex = 0
		courseInfoTables = response.xpath('//div[@class="courseattr popup"]/div/table').extract()
		# logTxt.write("course info :\n")
		for oneCourseInfo in courseInfoTables:		
			# logTxt.write(coursesInfo[courseIndex]['code'] + "\n")
			OneCourseInfoHeading = Selector(text = oneCourseInfo.replace('<br>',' ')).xpath("//th/text()").extract()
			dbHeadingDict = {'ATTRIBUTES':'attributes','ALTERNATE CODE(S)':'alternateCodes','CO-LIST WITH' :'colistWith','CO-REQUISITE': 'corequisite', 'DESCRIPTION': 'description','EXCLUSION': 'exclusion', 'INTENDED LEARNING OUTCOMES':'intendedLearningOutcomes','PRE-REQUISITE':'previousCode','VECTOR':'vector'}
			for key, value in dbHeadingDict.items():
				OneCourseInfoHeading = [oneHead.replace(key,value) for oneHead in OneCourseInfoHeading]
			# print("OneCourseInfoHeading :"+ str(OneCourseInfoHeading))
			OneCourseInfoContent = Selector(text = oneCourseInfo.replace('<br>',' ')).xpath("//td/text()").extract()
			for i in range(len(OneCourseInfoHeading)):
				coursesInfo[courseIndex][OneCourseInfoHeading[i]] = OneCourseInfoContent[i]
				# logTxt.write(OneCourseInfoHeading[i] + ": " + str(OneCourseInfoContent[i]) + "\n")
			courseIndex += 1
		courseIndex = 0
		coursesTables = response.xpath('//table[@class="sections"]').extract()
		heading = Selector(text=coursesTables[0]).xpath("//th/text()").extract()
		# print("heading :"+str(heading))
		dbHeadingDict = {'Section':'sectionId', 'Date & Time':'dateAndTime', 'Room':'room', 'Instructor': 'instructors', 'Quota':'quota', 'Enrol':'enrol', 'Avail':'avail', 'Wait':'wait',  'Remarks':'remarks'}
		for key, value in dbHeadingDict.items():
			heading = [oneHead.replace(key,value) for oneHead in heading]
		for courseTable in coursesTables:
			rows = Selector(text=courseTable).xpath("//tr[td]").extract()
			for oneRow in rows :
				sectionData = dict()
				sectionColumn = Selector(text=oneRow).xpath("//td").extract()
				# logTxt.write("sectionColumn: "+'\n'+str(sectionColumn)+"\n")
				if len(sectionColumn) >= len(heading) -1: 
					try:
						# print("heading : "+str(heading))
						for i in range(len(sectionColumn)):	
							sectionData[heading[i]]= Selector(text=sectionColumn[i]).xpath('//text()').extract()
							# if(heading[i] == "remarks"):
							# 	 sectionData[heading[i]].replace('\xa0','')
								#  sectionData['remarks'].replace('> ','')
						coursesInfo[courseIndex]['sections'].append(sectionData)
						# logTxt.write("--- the section is done ---\n"+str(coursesInfo[courseIndex])+"\n")
						# print ("*** one sectionColumn : "+'\n'+'\t'.join(sectionColumn)+"\n")
						
					except Exception as e:
						print ("Exception: "+type(e).__name__+'\n'+'\t'.join(sectionColumn)+"\n")
						# print (.join(sectionColumn)+"\n")
						# logTxt.write("Exception: "+type(e).__name__+'\n'+'\t'.join(sectionColumn)+"\n")
				else: 
					try:
						# print("coursesInfo[courseIndex]['sections'][-1] : "+ str(coursesInfo[courseIndex]['sections'][-1]))
						# logTxt.write("additional sectionColumn: "+'\n'+str(sectionColumn)+"\n")
						coursesInfo[courseIndex]['sections'][-1]['dateAndTime']+=Selector(text=sectionColumn[0]).xpath('//text()').extract()
						# logTxt.write(" sectionColumn(dateAndTime): "+'\n'+str(Selector(text=sectionColumn[0]).xpath('//text()').extract())+"\n")
						coursesInfo[courseIndex]['sections'][-1]['room']+=Selector(text=sectionColumn[1]).xpath('//text()').extract()
						# logTxt.write(" sectionColumn(room): "+'\n'+str(Selector(text=sectionColumn[1]).xpath('//text()').extract())+"\n")
						coursesInfo[courseIndex]['sections'][-1]['instructors']+=Selector(text=sectionColumn[2]).xpath('//text()').extract()
						# logTxt.write(" sectionColumn(instructors): "+'\n'+str(Selector(text=sectionColumn[2]).xpath('//text()').extract())+"\n")

					except Exception as e:
						print("Additional exception: "+type(e).__name__+'\n'+'\t'.join(sectionColumn)+"\n")
						logTxt.write("Additional exception: "+type(e).__name__+'\n'+'\t'.join(sectionColumn)+"\n")
			courseIndex+=1
		urlList = response.request.url.split('/')
		recordTime = urlList[4]+'-'+urlList[6]+'-'+urlList[7]+' '+urlList[8]+':'+urlList[9]
		for oneCourseInfo in coursesInfo:			

			if 'description' not in oneCourseInfo:
				oneCourseInfo['description'] = ''	
			if 'exclusion' not in oneCourseInfo:
				oneCourseInfo['exclusion'] = ''
			if 'prerequisite' not in oneCourseInfo:
				oneCourseInfo['prerequisite'] = ''	
				
		subject = coursesInfo[0]['code'][:4]
		print("inserting subject: " + subject + " with record time slot " + recordTime)

		for oneCourseInfo in coursesInfo:
			courseInfoCode = oneCourseInfo['code'].replace(' ','')
			savedCourse = self.db.course.find({"code" : courseInfoCode})
			self.log("savedCourse {}, type{} ".format(str(savedCourse),str(isinstance(savedCourse, dict))))
			courseExist = False
			if isinstance(savedCourse, dict):
				courseExist = True
			if (not courseExist):
				print ("inserting course " + courseInfoCode)
				self.db.course.insert(
					{ 
						"code": courseInfoCode, 
						"semester": semester,
						"title": oneCourseInfo['title'], 
						"credits" :int(oneCourseInfo['credits']), 
						"prerequisite" : oneCourseInfo['prerequisite'], 
						"exclusion" :  oneCourseInfo['exclusion'], 
						"description": oneCourseInfo['description'], 
						"sections": []
					}
				)
			for oneSection in oneCourseInfo['sections']:
				# print("oneSection['sections'] :"+str(oneSection))				
				# print("oneSection['sections'][0] :"+str(oneSection['sections'][0]))
				self.db.course.update({ "code": courseInfoCode }, {
					"$push": {
						"sections": {
							"recordTime": datetime.datetime.strptime(recordTime, "%Y-%m-%d %H:%M"),
							"sectionId": oneSection['sectionId'][0],
							"offerings": [{
								"dateAndTime": oneSection['dateAndTime'],
								"room": oneSection['room'],
								"instructors": [
									oneSection['instructors']
								]
							}],
							"quota": int(oneSection['quota'][0]),
							"enrol":  int(oneSection['enrol'][0]),
							"avail":  int(oneSection['avail'][0]),
							"wait":  int(oneSection['wait'][0]),
							"remarks":  oneSection['remarks'][0],
						}
					}
				})


